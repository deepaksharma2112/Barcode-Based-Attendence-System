-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2016 at 08:30 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `barcode`
--

-- --------------------------------------------------------

--
-- Table structure for table `cse_attd`
--

CREATE TABLE IF NOT EXISTS `cse_attd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Rollno` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Subject_Code` varchar(10) NOT NULL,
  `Attend` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`Rollno`),
  UNIQUE KEY `id` (`id`,`Subject_Code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `remeber`
--

CREATE TABLE IF NOT EXISTS `remeber` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(40) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`username`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `stud_info`
--

CREATE TABLE IF NOT EXISTS `stud_info` (
  `Name` varchar(20) NOT NULL,
  `Rollno` int(11) NOT NULL,
  `Fathers_name` varchar(20) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `e_mail` varchar(30) NOT NULL,
  `Stream` varchar(10) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Time` datetime NOT NULL,
  `Barcode` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`e_mail`),
  UNIQUE KEY `Roll no.` (`Rollno`),
  UNIQUE KEY `Barcode` (`Barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_info`
--

INSERT INTO `stud_info` (`Name`, `Rollno`, `Fathers_name`, `Address`, `e_mail`, `Stream`, `Password`, `Time`, `Barcode`) VALUES
('c ', 0, 'dv d', 'dvd', '', 'efe', '', '0000-00-00 00:00:00', NULL),
('Anajli', 1002, 'M S', 'Jldh', 'A@gmail.com', 'CSE', '1234qwer', '2016-07-28 14:47:02', NULL),
('abhishek rai', 1004, 'Mr sk', '32 A', 'abhishekrai041@gmail.com', 'CSE', '1234', '0000-00-00 00:00:00', 'abhishek rai1004'),
('abh', 1003, 'Mr.sk rai', '', 'avi', 'CSE', '1234556', '2016-09-20 00:00:00', NULL),
('Deepak', 1001, 'R K', 'Una', 'deepaksharma.51000@gmail.com', 'IT', '1234qwer', '2016-07-23 13:21:24', '55520031077');

-- --------------------------------------------------------

--
-- Table structure for table `sub_info`
--

CREATE TABLE IF NOT EXISTS `sub_info` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Subject name` varchar(30) NOT NULL,
  `Subject Code` varchar(10) NOT NULL,
  `Stream` varchar(10) NOT NULL,
  PRIMARY KEY (`Subject Code`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `sub_info`
--

INSERT INTO `sub_info` (`ID`, `Subject name`, `Subject Code`, `Stream`) VALUES
(7, 'Art of Programming', 'civ901', 'CIVIL'),
(8, 'Mechanics Of Solid', 'civ902', 'CIVIL'),
(9, 'Physics', 'civ903', 'CIVIL'),
(10, 'Elements Of Electrical Enginee', 'civ904', 'CIVIL'),
(11, 'Linear Algebra', 'civ905', 'CIVIL'),
(12, 'Foreign Language', 'civ906', 'CIVIL'),
(1, 'Computer Network', 'cs901', 'CSE'),
(2, 'Database Management System', 'cs902', 'CSE'),
(3, 'Human Resource Management ', 'cs903', 'CSE'),
(4, 'Object Oriented Programming Sy', 'cs904', 'CSE'),
(5, 'Computer Architecture', 'cs905', 'CSE'),
(6, 'System Programming', 'cs906', 'CSE'),
(19, 'Linear Circuits', 'ece901', 'Electronic'),
(20, 'Embedded Logic Design', 'ece902', 'Electronic'),
(21, 'Signals And Systems', 'ece903', 'Electronic'),
(22, 'Integrated Electronics', 'ece904', 'Electronic'),
(23, 'Fields And Waves', 'ece905', 'Electronic'),
(24, 'Principle Of Common Systems', 'ece906', 'Electronic'),
(31, 'elements Of Electrical Enginee', 'ee901', 'EE'),
(32, 'Analog Electronic Circuits', 'ee902', 'EE'),
(33, 'Digital Electronics', 'ee903', 'EE'),
(34, 'Control System Engineering', 'ee904', 'EE'),
(35, 'Engineering Electromagnetics', 'ee905', 'EE'),
(36, 'Analysis Of Electrical Power S', 'ee906', 'EE'),
(25, 'Computer Organisation', 'it901', 'IT'),
(26, 'Data Structures', 'it902', 'IT'),
(27, 'Web Designing', 'it903', 'IT'),
(28, 'Machine Human Interface', 'it904', 'IT'),
(29, 'Java Technology', 'it905', 'IT'),
(30, 'Software Engineering', 'it906', 'IT'),
(13, 'Thermodynamics', 'mec901', 'Mechanical'),
(14, 'Solid Mechanics', 'mec902', 'Mechanical'),
(15, 'Engineering Mechanics', 'mec903', 'Mechanical'),
(16, 'Engineering Drawing', 'mec904', 'Mechanical'),
(17, 'Mathematics', 'mec905', 'Mechanical'),
(18, 'introduction to computing', 'mec906', 'Mechanical');

-- --------------------------------------------------------

--
-- Table structure for table `teachers_info`
--

CREATE TABLE IF NOT EXISTS `teachers_info` (
  `T_name` varchar(20) NOT NULL,
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `e_maiL` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Stream` varchar(10) NOT NULL,
  `Status` varchar(10) NOT NULL,
  PRIMARY KEY (`e_maiL`),
  UNIQUE KEY `ID` (`ID`),
  UNIQUE KEY `ID_2` (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1001 ;

--
-- Dumping data for table `teachers_info`
--

INSERT INTO `teachers_info` (`T_name`, `ID`, `e_maiL`, `Password`, `Stream`, `Status`) VALUES
('Admin', 999, 'Admin', 'Admin', 'Admin', 'false'),
('hardeep', 2, 'D@gmail.com', '1232', 'Cse', 'false'),
('honey singh ', 1000, 'hoiney yoyo@gmail.com', 'honey111', 'IT', 'false');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
