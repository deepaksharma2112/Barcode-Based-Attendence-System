/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package login;
//for read decode
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;//1.BufferedImageLuminanceSource
import com.google.zxing.LuminanceSource;//2     
import com.google.zxing.common.HybridBinarizer;//3. HybridBinarizer(img)
import com.google.zxing.BinaryBitmap;//4 
import com.google.zxing.MultiFormatReader;//5
import com.google.zxing.Reader;//6
import com.google.zxing.Result;//7

//create 
import com.google.zxing.BarcodeFormat;
import com.google.zxing.ChecksumException;
import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
//import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.oned.*;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.encoder.QRCode;
//basic need
//for input
import java.io.File;
import java.io.FileOutputStream;
//for output
import java.io.FileInputStream;
import java.io.InputStream;
import java.awt.image.BufferedImage;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.imageio.ImageIO;


/**
 *
 * @author waheguru
 */
public class Barcode {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        String rowMsg=javax.swing.JOptionPane.showInputDialog("Enter your code");
        
        Create(rowMsg,new File(".\\Cp.png"));
      
        String filePath=".\\Cp.png";
        InputStream barCodeInputStream = new FileInputStream(filePath);  
        BufferedImage barCodeBufferedImage = ImageIO.read(barCodeInputStream);
        
        String Message=readBarCode(barCodeBufferedImage);
       
       }
    

public static void Create(String text,File f)
{
 try{ 
       

int width  = 400;
int height = 100; 
String imgFormat = "png";

       
BitMatrix bitMatrix = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, width, height);  
MatrixToImageWriter.writeToStream(bitMatrix, imgFormat, new FileOutputStream(f));
 
       }
       catch(Exception e)
       {
           System.out.println(e);
       }

}




public static String readBarCode(BufferedImage BufferedImage)
       

{
    String string="";
    BufferedImage image = null;
    try {
        
        BufferedImage barCodeBufferedImage = BufferedImage;  
        LuminanceSource source = new BufferedImageLuminanceSource(barCodeBufferedImage);  
        BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));  
        
        
        Reader reader = new MultiFormatReader();  
        Result result = reader.decode(bitmap);  
       javax.swing.JOptionPane.showMessageDialog(null, "QRcode text is " + result.getText());
        System.out.println("QRcode text is " + result.getText());
        string=result.getText();
        } 
    catch (NotFoundException | ChecksumException | FormatException ex) {
       System.err.println(""+ex);
       
    }    
    return string;
}
}


