package login;
import javax.mail.internet.*;
import javax.mail.*;
import java.util.Properties;
import javax.swing.*;
import javax.activation.*;
public class Email {
    public static void main(String[] args) {
        
        
        
        
        
    }
  static public  boolean sendEmail(String uemail,String epassword,String semail,String Esub,String name,String branch,String rollno ){
         final String username = uemail;
        final String password = epassword;
final String to=semail;
final String sub="ID Card";


//create properties array
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        
        //Authenticator
javax.mail.Authenticator a=new Authenticator(){ protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }};
//create Session
        Session session = Session.getInstance(props,a);

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(to));
            message.setSubject(sub);



 // This mail has 2 part, the BODY and the embedded image
         MimeMultipart multipart = new MimeMultipart("related");

         // first part (the html)
         BodyPart messageBodyPart = new MimeBodyPart();
         String htmlText = "<H2>Hello, </H2>"+name+" <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+rollno+"("+branch+")<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;your ID Proof is here.....";
         messageBodyPart.setContent(htmlText, "text/html");
         // add it
         multipart.addBodyPart(messageBodyPart);

         // second part (the image)
         messageBodyPart = new MimeBodyPart();
         DataSource fds = new FileDataSource(
            ".\\canvas1.png");

         messageBodyPart.setDataHandler(new DataHandler(fds));
         messageBodyPart.setHeader("Content-ID", "<image>");
       //  messageBodyPart.setText("ID Proof");
        

         // add image to the multipart
         multipart.addBodyPart(messageBodyPart);

         // put everything together
         message.setContent(multipart);





            //message.setText(comp);

            Transport.send(message);

            JOptionPane.showMessageDialog(null, "Mail Send");
        } catch (MessagingException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        
return true;
    }
    
}
