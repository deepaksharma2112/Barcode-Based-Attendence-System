/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;
import java.util.Vector;
import java.sql.*;
/**
 *
 * @author Deepak
 */
public class Remove {
    
 static public  void   teacherView(){
    
     try {
            Vector cvector=new Vector();
            Vector rvector=new Vector();
            
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/barcode","root","");
            Statement stmt=conn.createStatement();
                    ResultSet rs=stmt.executeQuery("Select * from teachers_info");
                    ResultSetMetaData metadatarsm=rs.getMetaData();
//Meta data
                    int size=metadatarsm.getColumnCount();
//Number of column
                    for(int i=1;i<=size;i++)//loop for store in vector
                    {
                        cvector.add(metadatarsm.getColumnName(i));//column vector
                    }
                    while(rs.next()){
                            Vector data=new Vector();
                                    data.add(rs.getString(1));
                                    data.add(rs.getInt(2));
                                    data.add(rs.getString(3));
                                    data.add(rs.getString(4));
                                    data.add(rs.getString(5));
                                    data.add(rs.getString(6));
                                
                                    rvector.add(data);
                                    }
                                    
                   
                   View f=new View();
                   f.jta.setModel(new javax.swing.table.DefaultTableModel(rvector, cvector));
                   f.header.setText("Teacher View");
                   f.setTitle("Teacher View");
                   f.setVisible(true);
                    //f.setVisible(true);
                                    
                                    } catch (ClassNotFoundException ex) {
            System.out.println(""+ex);
        } catch (SQLException ex) {
           System.out.println(""+ex);
        }
    }
  
 static public void studentView()
  {
    try {
            Vector cvector=new Vector();
            Vector rvector=new Vector();
            
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/barcode","root","");
            Statement stmt=conn.createStatement();
                    ResultSet rs=stmt.executeQuery("Select * from stud_info");
                    ResultSetMetaData metadatarsm=rs.getMetaData();
//Meta data
                    int size=metadatarsm.getColumnCount();
//Number of column
                    for(int i=1;i<=size;i++)//loop for store in vector
                    {
                        cvector.add(metadatarsm.getColumnName(i));//column vector
                    }
                    while(rs.next()){
                            Vector data=new Vector();
                                    data.add(rs.getString(1));
                                    data.add(rs.getInt(2));
                                    data.add(rs.getString(3));
                                    data.add(rs.getString(4));
                                    data.add(rs.getString(5));
                                    data.add(rs.getString(6));
                                    data.add(rs.getString(7));
                                
                                    rvector.add(data);
                                    }
                                    
                   
                   View f=new View();
                   f.jta.setModel(new javax.swing.table.DefaultTableModel(rvector, cvector));
                   f.header.setText("Student View");
                   f.setTitle("Student View");
                   f.setVisible(true);
                    //f.setVisible(true);
                                    
                                    } catch (ClassNotFoundException ex) {
            System.out.println(""+ex);
        } catch (SQLException ex) {
           System.out.println(""+ex);
        }
  
  }
 
 static public void studentAttdView()
 {
 try {
            Vector cvector=new Vector();
            Vector rvector=new Vector();
            
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/barcode","root","");
            Statement stmt=conn.createStatement();
                    ResultSet rs=stmt.executeQuery("Select * from cse_attd");
                    ResultSetMetaData metadatarsm=rs.getMetaData();
//Meta data
                    int size=metadatarsm.getColumnCount();
//Number of column
                    for(int i=1;i<=size;i++)//loop for store in vector
                    {
                        cvector.add(metadatarsm.getColumnName(i));//column vector
                    }
                    while(rs.next()){
                            Vector data=new Vector();
                                    data.add(rs.getInt(1));
                                    data.add(rs.getInt(2));
                                    data.add(rs.getString(3));
                                    data.add(rs.getString(4));
                                    data.add(rs.getString(5));
                                    rvector.add(data);
                                    }
                                    
                   
                   View f=new View();
                   f.jta.setModel(new javax.swing.table.DefaultTableModel(rvector, cvector));
                   f.header.setText("Student Attendence View");
                   f.setTitle("Student Attendence View");
                   
                   f.setVisible(true);
                    //f.setVisible(true);
                                    
                                    } catch (ClassNotFoundException ex) {
            System.out.println(""+ex);
        } catch (SQLException ex) {
           System.out.println(""+ex);
        }
 
 }
  
    
}
