/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.awt.Graphics;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author pc
 */
public class StdReg extends javax.swing.JFrame {
String epassword="";
    /**
     * Creates new form StdReg
     */
    public StdReg() {
        initComponents();
    SRPBOTTOM1.setVisible(true);
    SRPTOP.setVisible(true);
    SRPBOTTOM2.setVisible(false);
    Display.setVisible(false);
    }

    
    @SuppressWarnings("unchecked")
  // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
  private void initComponents() {

    Display = new javax.swing.JPanel();
    jButton4 = new javax.swing.JButton();
    jButton5 = new javax.swing.JButton();
    jScrollPane1 = new javax.swing.JScrollPane();
    jPanel1 = new javax.swing.JPanel();
    show = new javax.swing.JButton();
    SRPMain = new javax.swing.JPanel();
    SRPBOTTOM1 = new javax.swing.JPanel();
    SRPBOTTOM1NameF = new javax.swing.JTextField();
    SRPBOTTOM1SF = new javax.swing.JTextField();
    SRPBOTTOM1EMF = new javax.swing.JTextField();
    SRPBOTTOM1FNameF = new javax.swing.JTextField();
    SRPBOTTOM1BF = new javax.swing.JTextField();
    jButton2 = new javax.swing.JButton();
    jLabel2 = new javax.swing.JLabel();
    jLabel4 = new javax.swing.JLabel();
    jLabel5 = new javax.swing.JLabel();
    jLabel7 = new javax.swing.JLabel();
    jLabel8 = new javax.swing.JLabel();
    SRPTOP = new javax.swing.JPanel();
    SRTopRollnoF = new javax.swing.JTextField();
    jButton1 = new javax.swing.JButton();
    jLabel3 = new javax.swing.JLabel();
    SRTOPSC = new javax.swing.JComboBox();
    jLabel1 = new javax.swing.JLabel();
    SRPBOTTOM2 = new javax.swing.JPanel();
    SRPBOTTOM2_StreamLable = new javax.swing.JLabel();
    jButton3 = new javax.swing.JButton();
    L1 = new javax.swing.JLabel();
    L2 = new javax.swing.JLabel();
    L3 = new javax.swing.JLabel();
    L4 = new javax.swing.JLabel();
    L5 = new javax.swing.JLabel();
    L6 = new javax.swing.JLabel();
    jButton6 = new javax.swing.JButton();

    setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
    setMinimumSize(new java.awt.Dimension(621, 533));
    getContentPane().setLayout(null);

    Display.setPreferredSize(new java.awt.Dimension(620, 530));

    jButton4.setText("Submitt All");
    jButton4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton4ActionPerformed(evt);
      }
    });

    jButton5.setText("back");
    jButton5.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton5ActionPerformed(evt);
      }
    });

    jScrollPane1.setPreferredSize(new java.awt.Dimension(620, 530));

    jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
    jPanel1.setPreferredSize(new java.awt.Dimension(700, 474));

    javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
    jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(
      jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGap(0, 698, Short.MAX_VALUE)
    );
    jPanel1Layout.setVerticalGroup(
      jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGap(0, 472, Short.MAX_VALUE)
    );

    jScrollPane1.setViewportView(jPanel1);

    show.setText("show");
    show.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        showActionPerformed(evt);
      }
    });

    javax.swing.GroupLayout DisplayLayout = new javax.swing.GroupLayout(Display);
    Display.setLayout(DisplayLayout);
    DisplayLayout.setHorizontalGroup(
      DisplayLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(DisplayLayout.createSequentialGroup()
        .addGap(524, 524, 524)
        .addComponent(jButton5)
        .addGap(0, 0, Short.MAX_VALUE))
      .addGroup(DisplayLayout.createSequentialGroup()
        .addContainerGap()
        .addComponent(show)
        .addGap(117, 117, 117)
        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
      .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, DisplayLayout.createSequentialGroup()
        .addContainerGap()
        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        .addContainerGap())
    );
    DisplayLayout.setVerticalGroup(
      DisplayLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(DisplayLayout.createSequentialGroup()
        .addGap(7, 7, 7)
        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addGap(16, 16, 16)
        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 395, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addGroup(DisplayLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
          .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addComponent(show))
        .addContainerGap(39, Short.MAX_VALUE))
    );

    getContentPane().add(Display);
    Display.setBounds(0, 0, 620, 530);

    SRPMain.setLayout(null);

    SRPBOTTOM1NameF.setEnabled(false);

    SRPBOTTOM1SF.setEnabled(false);

    SRPBOTTOM1EMF.setEnabled(false);

    SRPBOTTOM1FNameF.setEnabled(false);

    jButton2.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
    jButton2.setText("Submit");
    jButton2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton2ActionPerformed(evt);
      }
    });

    jLabel2.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
    jLabel2.setText("Barcode");
    jLabel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

    jLabel4.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
    jLabel4.setText("Stream");
    jLabel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

    jLabel5.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
    jLabel5.setText("email");
    jLabel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

    jLabel7.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
    jLabel7.setText("Father name");
    jLabel7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

    jLabel8.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
    jLabel8.setText("Name");
    jLabel8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

    javax.swing.GroupLayout SRPBOTTOM1Layout = new javax.swing.GroupLayout(SRPBOTTOM1);
    SRPBOTTOM1.setLayout(SRPBOTTOM1Layout);
    SRPBOTTOM1Layout.setHorizontalGroup(
      SRPBOTTOM1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(SRPBOTTOM1Layout.createSequentialGroup()
        .addGap(49, 49, 49)
        .addGroup(SRPBOTTOM1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
          .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 86, Short.MAX_VALUE)
        .addGroup(SRPBOTTOM1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
          .addGroup(SRPBOTTOM1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
            .addComponent(SRPBOTTOM1SF, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
            .addComponent(SRPBOTTOM1EMF, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
            .addComponent(SRPBOTTOM1BF))
          .addComponent(SRPBOTTOM1NameF, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addComponent(SRPBOTTOM1FNameF, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE))
        .addGap(90, 90, 90))
      .addGroup(SRPBOTTOM1Layout.createSequentialGroup()
        .addGap(212, 212, 212)
        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    );
    SRPBOTTOM1Layout.setVerticalGroup(
      SRPBOTTOM1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(SRPBOTTOM1Layout.createSequentialGroup()
        .addGap(37, 37, 37)
        .addGroup(SRPBOTTOM1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
          .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addComponent(SRPBOTTOM1NameF, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
        .addGap(18, 18, 18)
        .addGroup(SRPBOTTOM1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
          .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addComponent(SRPBOTTOM1FNameF, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
        .addGap(18, 18, 18)
        .addGroup(SRPBOTTOM1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
          .addComponent(SRPBOTTOM1SF, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
        .addGap(16, 16, 16)
        .addGroup(SRPBOTTOM1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
          .addComponent(SRPBOTTOM1EMF, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
        .addGap(18, 18, 18)
        .addGroup(SRPBOTTOM1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
          .addComponent(SRPBOTTOM1BF, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
        .addGap(47, 47, 47)
        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addContainerGap(44, Short.MAX_VALUE))
    );

    SRPMain.add(SRPBOTTOM1);
    SRPBOTTOM1.setBounds(0, 100, 620, 430);

    SRTopRollnoF.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        SRTopRollnoFActionPerformed(evt);
      }
    });

    jButton1.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
    jButton1.setText("GO");
    jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton1ActionPerformed(evt);
      }
    });

    jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
    jLabel3.setText("Roll NO");
    jLabel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

    SRTOPSC.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Dec. 2016", "May. 2017", "Dec. 2017", "May. 2018", "Dec. 2018" }));

    jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
    jLabel1.setText("Session");
    jLabel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

    javax.swing.GroupLayout SRPTOPLayout = new javax.swing.GroupLayout(SRPTOP);
    SRPTOP.setLayout(SRPTOPLayout);
    SRPTOPLayout.setHorizontalGroup(
      SRPTOPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SRPTOPLayout.createSequentialGroup()
        .addGroup(SRPTOPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
          .addGroup(SRPTOPLayout.createSequentialGroup()
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
          .addGroup(SRPTOPLayout.createSequentialGroup()
            .addGap(26, 26, 26)
            .addComponent(jLabel1)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(SRTOPSC, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(129, 129, 129)
            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
            .addComponent(SRTopRollnoF, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
        .addGap(37, 37, 37))
    );
    SRPTOPLayout.setVerticalGroup(
      SRPTOPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(SRPTOPLayout.createSequentialGroup()
        .addGroup(SRPTOPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
          .addGroup(SRPTOPLayout.createSequentialGroup()
            .addGap(5, 5, 5)
            .addGroup(SRPTOPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
              .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
              .addComponent(SRTOPSC, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
          .addGroup(SRPTOPLayout.createSequentialGroup()
            .addContainerGap()
            .addGroup(SRPTOPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
              .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
              .addComponent(SRTopRollnoF, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        .addContainerGap())
    );

    SRPMain.add(SRPTOP);
    SRPTOP.setBounds(0, 0, 620, 100);

    SRPBOTTOM2_StreamLable.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
    SRPBOTTOM2_StreamLable.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    SRPBOTTOM2_StreamLable.setText("CSE");
    SRPBOTTOM2_StreamLable.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

    jButton3.setFont(new java.awt.Font("Tahoma", 2, 24)); // NOI18N
    jButton3.setText("Submit");
    jButton3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton3ActionPerformed(evt);
      }
    });

    L1.setText("jLabel6");

    L2.setText("jLabel9");

    L3.setText("jLabel10");

    L4.setText("jLabel11");

    L5.setText("jLabel12");

    L6.setText("jLabel13");

    jButton6.setText("back");
    jButton6.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton6ActionPerformed(evt);
      }
    });

    javax.swing.GroupLayout SRPBOTTOM2Layout = new javax.swing.GroupLayout(SRPBOTTOM2);
    SRPBOTTOM2.setLayout(SRPBOTTOM2Layout);
    SRPBOTTOM2Layout.setHorizontalGroup(
      SRPBOTTOM2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(SRPBOTTOM2Layout.createSequentialGroup()
        .addGroup(SRPBOTTOM2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
          .addGroup(SRPBOTTOM2Layout.createSequentialGroup()
            .addGap(61, 61, 61)
            .addComponent(SRPBOTTOM2_StreamLable, javax.swing.GroupLayout.PREFERRED_SIZE, 394, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(jButton6))
          .addGroup(SRPBOTTOM2Layout.createSequentialGroup()
            .addGap(81, 81, 81)
            .addGroup(SRPBOTTOM2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
              .addComponent(L1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
              .addComponent(L5, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
              .addComponent(L3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGap(98, 98, 98)
            .addGroup(SRPBOTTOM2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
              .addComponent(L2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
              .addComponent(L4, javax.swing.GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE)
              .addComponent(L6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
          .addGroup(SRPBOTTOM2Layout.createSequentialGroup()
            .addGap(232, 232, 232)
            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)))
        .addContainerGap(62, Short.MAX_VALUE))
    );
    SRPBOTTOM2Layout.setVerticalGroup(
      SRPBOTTOM2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(SRPBOTTOM2Layout.createSequentialGroup()
        .addGroup(SRPBOTTOM2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
          .addGroup(SRPBOTTOM2Layout.createSequentialGroup()
            .addGap(22, 22, 22)
            .addComponent(SRPBOTTOM2_StreamLable, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
          .addGroup(SRPBOTTOM2Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(jButton6)))
        .addGap(31, 31, 31)
        .addGroup(SRPBOTTOM2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
          .addComponent(L1, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
          .addComponent(L2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        .addGap(34, 34, 34)
        .addGroup(SRPBOTTOM2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
          .addComponent(L4, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
          .addComponent(L3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        .addGap(18, 18, 18)
        .addGroup(SRPBOTTOM2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
          .addComponent(L5, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
          .addComponent(L6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addGap(67, 67, 67))
    );

    SRPMain.add(SRPBOTTOM2);
    SRPBOTTOM2.setBounds(0, 100, 620, 430);

    getContentPane().add(SRPMain);
    SRPMain.setBounds(0, 0, 620, 530);

    pack();
  }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        SRPBOTTOM2_StreamLable.setText(SRPBOTTOM1SF.getText());
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql:///barcode","root","");
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery("select * from sub_info where Stream='"+SRPBOTTOM1SF.getText()+"'");
           rs.next();
           L1.setText(rs.getString(2)+"   "+rs.getString(3));
            rs.next();
           L2.setText(rs.getString(2)+"   "+rs.getString(3));
            rs.next();
           L3.setText(rs.getString(2)+"   "+rs.getString(3));
            rs.next();
           L4.setText(rs.getString(2)+"   "+rs.getString(3));
            rs.next();
           L5.setText(rs.getString(2)+"   "+rs.getString(3));
            if(rs.next())
           L6.setText(rs.getString(2)+"   "+rs.getString(3));
            
            Display.setVisible(false);
            SRPTOP.setVisible(true);
            SRPBOTTOM1.setVisible(false);
          SRPBOTTOM2.setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(StdReg.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(StdReg.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      
          
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql:///barcode","root","");
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery("select * from stud_info where Rollno='"+SRTopRollnoF.getText()+"'");
       if(rs.next())
       {
         SRPBOTTOM1NameF.setText(rs.getString("Name"));
         SRPBOTTOM1FNameF.setText(rs.getString("Fathers_name"));
         SRPBOTTOM1EMF.setText(rs.getString("e_mail"));
         SRPBOTTOM1SF.setText(rs.getString("Stream"));
         SRPBOTTOM1BF.setText(SRPBOTTOM1NameF.getText()+SRTopRollnoF.getText());
       }
       else{
           JOptionPane.showMessageDialog(this, "Wrong username");
           SRTopRollnoF.setText("");
       }
        con.close();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(StdReg.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(StdReg.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }//GEN-LAST:event_jButton1ActionPerformed

    private void SRTopRollnoFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SRTopRollnoFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SRTopRollnoFActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        String email=SRPBOTTOM1EMF.getText();
        String name=SRPBOTTOM1NameF.getText();
        String Branch=SRPBOTTOM1SF.getText();
        String Barcd=SRPBOTTOM1BF.getText();
        Barcode.Create(Barcd,new File(".\\Cp.png"));
            SRPBOTTOM1.setVisible(false);
    SRPTOP.setVisible(false);
    SRPBOTTOM2.setVisible(false);
    Display.setVisible(true);
        NewJFrame.canvas(jPanel1,new File(".\\Cp.png"),new File(".\\Card-setup-9.png"), name, SRTopRollnoF.getText(), Branch);
        
        
        
    
        
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       
        
            epassword=JOptionPane.showInputDialog(null, "enter user password");
        if(!epassword.equals("")){
        try {
            //send barcode in database and email canvas to emailadress
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql:///barcode","root","");
            Statement stmt=con.createStatement();
            int  rs=stmt.executeUpdate("update  stud_info set Barcode='" +SRPBOTTOM1BF.getText()+"' where e_mail='"+SRPBOTTOM1EMF.getText()+"'   ");
       
            if(rs==1)
       {
  
           new Thread(){
          @Override
          public void run() {
             Email.sendEmail("deepak.d786d@gmail.com",epassword , SRPBOTTOM1EMF.getText(),"ID Proof", SRPBOTTOM1NameF.getText(), SRPBOTTOM1SF.getText(), SRTopRollnoF.getText());
          }
      }.start();
       
       }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(StdReg.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(StdReg.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        
        
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
         
        SRPBOTTOM1.setVisible(false);
    SRPTOP.setVisible(true);
    SRPBOTTOM2.setVisible(true);
    Display.setVisible(false);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
       Display.setVisible(false);
            SRPTOP.setVisible(true);
            SRPBOTTOM1.setVisible(true);
          SRPBOTTOM2.setVisible(false);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void showActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showActionPerformed
        try {
            File canvas1=new File(".\\canvas1.png");
            
            Graphics g2=jPanel1.getGraphics();
            g2.drawImage(javax.imageio.ImageIO.read(canvas1),0, 0, null);
            
            jPanel1.setVisible(true);
            
            // TODO add your handling code here:
        } catch (IOException ex) {
            Logger.getLogger(StdReg.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_showActionPerformed
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StdReg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StdReg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StdReg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StdReg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StdReg().setVisible(true);
            }
        });
    }

  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JPanel Display;
  private javax.swing.JLabel L1;
  private javax.swing.JLabel L2;
  private javax.swing.JLabel L3;
  private javax.swing.JLabel L4;
  private javax.swing.JLabel L5;
  private javax.swing.JLabel L6;
  private javax.swing.JPanel SRPBOTTOM1;
  private javax.swing.JTextField SRPBOTTOM1BF;
  private javax.swing.JTextField SRPBOTTOM1EMF;
  private javax.swing.JTextField SRPBOTTOM1FNameF;
  private javax.swing.JTextField SRPBOTTOM1NameF;
  private javax.swing.JTextField SRPBOTTOM1SF;
  private javax.swing.JPanel SRPBOTTOM2;
  private javax.swing.JLabel SRPBOTTOM2_StreamLable;
  private javax.swing.JPanel SRPMain;
  private javax.swing.JPanel SRPTOP;
  private javax.swing.JComboBox SRTOPSC;
  private javax.swing.JTextField SRTopRollnoF;
  private javax.swing.JButton jButton1;
  private javax.swing.JButton jButton2;
  private javax.swing.JButton jButton3;
  private javax.swing.JButton jButton4;
  private javax.swing.JButton jButton5;
  private javax.swing.JButton jButton6;
  private javax.swing.JLabel jLabel1;
  private javax.swing.JLabel jLabel2;
  private javax.swing.JLabel jLabel3;
  private javax.swing.JLabel jLabel4;
  private javax.swing.JLabel jLabel5;
  private javax.swing.JLabel jLabel7;
  private javax.swing.JLabel jLabel8;
  private javax.swing.JPanel jPanel1;
  private javax.swing.JScrollPane jScrollPane1;
  private javax.swing.JButton show;
  // End of variables declaration//GEN-END:variables
}
