/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.ChecksumException;


import com.google.zxing.client.j2se.BufferedImageLuminanceSource;//1.BufferedImageLuminanceSource
import com.google.zxing.LuminanceSource;//2     
import com.google.zxing.common.HybridBinarizer;//3. HybridBinarizer(img)
import com.google.zxing.BinaryBitmap;//4 
import com.google.zxing.MultiFormatReader;//5
import com.google.zxing.Reader;//6
import com.google.zxing.Result;//7

//create 
import com.google.zxing.BarcodeFormat;
import com.google.zxing.ChecksumException;
import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
//import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.oned.*;
import java.awt.Graphics2D;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
//basic need
//for input
import java.io.File;
import java.io.FileOutputStream;
//for output
import java.io.FileInputStream;
import java.io.InputStream;
import java.awt.image.BufferedImage;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFrame;

/**
 *
 * @author Deepak
 */
public class Web_Barcode {
  static  javax.swing.JFrame window ;
 public static  Webcam webcam ;
    public static void main(String[] args) {
        
     
                
		WebcamPanel panel = new WebcamPanel(webcam);
		panel.setFPSDisplayed(true);
		panel.setDisplayDebugInfo(true);
		panel.setImageSizeDisplayed(true);
		panel.setMirrored(true);

		window = new JFrame();
		window.setTitle("Test webcam panel");
                window.add(panel);
		window.setResizable(true);
		
		panel.setVisible(true);
                 window.pack();
		window.setVisible(true);
        window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        window.addWindowListener(new WindowAdapter() {
    public void WindowClosing(WindowEvent e) {
        System.out.println("test");
        window.dispose();
    }
});
        
               new Thread("capture"){

            @Override
            public void run() {
              //  super.run(); //To change body of generated methods, choose Tools | Templates.
           
       while(true){
                    try {
                        Thread.sleep(2000);
                        // get image
                        BufferedImage image = webcam.getImage();
                        if(!java1.subCode.getText().equals("") && java1.subCode.getText().length()>4){
                        String msg=Barcod.readBarCode(image);
                        if(msg!=""){
                           // javax.swing.JOptionPane.showMessageDialog(window, msg);
                           ShowInfo si=new ShowInfo();
                            try {
                                Class.forName("com.mysql.jdbc.Driver");
                            
            Connection con=DriverManager.getConnection("jdbc:mysql:///barcode","root","");
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery("select * from stud_info where Barcode='"+msg+"'");
            
            if(rs.next())
            {
              String name=rs.getString(1);
             int rollno=rs.getInt(2);
             String branch=rs.getString(6);
             
             si.barcode.setText(msg);
             si.branch.setText(branch);
             si.rollno.setText(String.valueOf(rollno));
             si.name.setText(name);
              si.subcode.setText(java1.subCode.getText());
              si.setVisible(true);
            }
            
                } catch (ClassNotFoundException ex) {
                                Logger.getLogger(Web_Barcode.class.getName()).log(Level.SEVERE, null, ex);
                            } catch (SQLException ex) {
                                Logger.getLogger(Web_Barcode.class.getName()).log(Level.SEVERE, null, ex);
                            }           
                           
                           
                           
                        }
                        }
                         } catch (InterruptedException ex) {
                        Logger.getLogger(Web_Barcode.class.getName()).log(Level.SEVERE, null, ex);
                    }
        
        }
            } }.start();
                
        
        
        
    }
  
    
    
    
}

class Barcod {

    /**
     * @param args the command line arguments
     */
    
   
public static String readBarCode(BufferedImage BufferedImage)
       

{
    String string="";
    BufferedImage image = null;
    try {
        
        BufferedImage barCodeBufferedImage = BufferedImage;  
        LuminanceSource source = new BufferedImageLuminanceSource(barCodeBufferedImage);  
        BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));  
        
        
        Reader reader = new MultiFormatReader();  
        Result result = reader.decode(bitmap);  
  
        System.out.println("Barcode text is " + result.getText());
        string=result.getText();
        } 
    catch (NotFoundException | ChecksumException | FormatException ex) {
       System.err.println(""+ex);
       
    }    
    return string;
}
}


