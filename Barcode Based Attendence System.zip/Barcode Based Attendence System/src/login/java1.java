
package login;

import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamResolution;
import java.awt.Color;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.Clock;
import java.util.Timer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static login.Web_Barcode.webcam;
public class java1 extends javax.swing.JFrame {
  boolean webcam=false;
  boolean rem=false;
    private static Object awt;
    public java.util.Date startt;
     boolean starttime=false;
      BarcodeReader bar;
    public java1() {
        initComponents();
        setttime();
        rem();
       Adminview.setVisible(false);
       teacherview.setVisible(false);
       reg.setVisible(false);
       login.setVisible(true);
    }
 
   private void rem()
    {
   
       try {
           Class.forName("com.mysql.jdbc.Driver");
           
           Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/barcode","root","");
           
           
           Statement stmt=con.createStatement();
          ResultSet rs= stmt.executeQuery("select * from remeber");
           while(rs.next()){
           utextf.setText(rs.getString(2));
           ptextf.setText(rs.getString(3));
           utextf.setBackground(Color.LIGHT_GRAY);
           ptextf.setBackground(Color.LIGHT_GRAY);
           }
           stmt.close();
       } catch (ClassNotFoundException ex) {
           Logger.getLogger(java1.class.getName()).log(Level.SEVERE, null, ex);
       } catch (SQLException ex) {
           Logger.getLogger(java1.class.getName()).log(Level.SEVERE, null, ex);
       }
    
    
    }
  
    @SuppressWarnings("unchecked")
  // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
  private void initComponents() {

    jLabel20 = new javax.swing.JLabel();
    Adminview = new javax.swing.JPanel();
    jLabel3 = new javax.swing.JLabel();
    jButton5 = new javax.swing.JButton();
    jButton6 = new javax.swing.JButton();
    jButton7 = new javax.swing.JButton();
    jButton8 = new javax.swing.JButton();
    jPanel3 = new javax.swing.JPanel();
    jPanel1 = new javax.swing.JPanel();
    jLabel15 = new javax.swing.JLabel();
    jLabel21 = new javax.swing.JLabel();
    reg = new javax.swing.JPanel();
    TN = new javax.swing.JTextField();
    BSubmit = new javax.swing.JButton();
    EM = new javax.swing.JTextField();
    jLabel1 = new javax.swing.JLabel();
    jLabel2 = new javax.swing.JLabel();
    jLabel4 = new javax.swing.JLabel();
    jLabel5 = new javax.swing.JLabel();
    jLabel6 = new javax.swing.JLabel();
    jLabel7 = new javax.swing.JLabel();
    jLabel8 = new javax.swing.JLabel();
    jLabel10 = new javax.swing.JLabel();
    PS = new javax.swing.JTextField();
    CPS = new javax.swing.JTextField();
    jButton3 = new javax.swing.JButton();
    ST = new javax.swing.JComboBox();
    jPanel2 = new javax.swing.JPanel();
    jLabel9 = new javax.swing.JLabel();
    login = new javax.swing.JPanel();
    jLabel11 = new javax.swing.JLabel();
    jLabel12 = new javax.swing.JLabel();
    utextf = new javax.swing.JTextField();
    jLabel13 = new javax.swing.JLabel();
    ptextf = new javax.swing.JTextField();
    jButton1 = new javax.swing.JButton();
    jButton2 = new javax.swing.JButton();
    remeber = new javax.swing.JCheckBox();
    jLabel19 = new javax.swing.JLabel();
    back = new javax.swing.JLabel();
    teacherview = new javax.swing.JPanel();
    jButton9 = new javax.swing.JButton();
    jButton4 = new javax.swing.JButton();
    jButton10 = new javax.swing.JButton();
    jButton11 = new javax.swing.JButton();
    subCode = new javax.swing.JTextField();
    jLabel14 = new javax.swing.JLabel();
    jButton12 = new javax.swing.JButton();
    timelb = new javax.swing.JLabel();
    jLabel17 = new javax.swing.JLabel();
    Start = new javax.swing.JLabel();
    jLabel18 = new javax.swing.JLabel();
    Stop = new javax.swing.JLabel();
    jLabel16 = new javax.swing.JLabel();
    back11 = new javax.swing.JLabel();

    jLabel20.setText("jLabel20");

    setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
    setBackground(new java.awt.Color(0, 204, 177));
    setName("frm"); // NOI18N
    setPreferredSize(new java.awt.Dimension(633, 540));
    setResizable(false);
    getContentPane().setLayout(null);

    Adminview.setPreferredSize(new java.awt.Dimension(638, 517));
    Adminview.setLayout(null);

    jLabel3.setBackground(new java.awt.Color(0, 204, 177));
    jLabel3.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
    jLabel3.setForeground(new java.awt.Color(255, 255, 255));
    jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel3.setText("      ADMIN");
    jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
    Adminview.add(jLabel3);
    jLabel3.setBounds(0, 3, 640, 90);

    jButton5.setBackground(new java.awt.Color(0, 204, 177));
    jButton5.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
    jButton5.setForeground(new java.awt.Color(255, 255, 255));
    jButton5.setText("Reg. Student");
    jButton5.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    jButton5.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton5ActionPerformed(evt);
      }
    });
    Adminview.add(jButton5);
    jButton5.setBounds(310, 133, 296, 70);

    jButton6.setBackground(new java.awt.Color(0, 204, 177));
    jButton6.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
    jButton6.setForeground(new java.awt.Color(255, 255, 255));
    jButton6.setText("View Student");
    jButton6.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    jButton6.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton6ActionPerformed(evt);
      }
    });
    Adminview.add(jButton6);
    jButton6.setBounds(310, 210, 297, 70);

    jButton7.setBackground(new java.awt.Color(0, 204, 177));
    jButton7.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
    jButton7.setForeground(new java.awt.Color(255, 255, 255));
    jButton7.setText("Teacher View");
    jButton7.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    jButton7.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton7ActionPerformed(evt);
      }
    });
    Adminview.add(jButton7);
    jButton7.setBounds(310, 290, 297, 70);

    jButton8.setBackground(new java.awt.Color(0, 204, 177));
    jButton8.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
    jButton8.setForeground(new java.awt.Color(255, 255, 255));
    jButton8.setText("Logout");
    jButton8.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    jButton8.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton8ActionPerformed(evt);
      }
    });
    Adminview.add(jButton8);
    jButton8.setBounds(310, 370, 297, 70);

    jPanel3.setBackground(new java.awt.Color(0, 204, 177));
    jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

    javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
    jPanel3.setLayout(jPanel3Layout);
    jPanel3Layout.setHorizontalGroup(
      jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGap(0, 636, Short.MAX_VALUE)
    );
    jPanel3Layout.setVerticalGroup(
      jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGap(0, 95, Short.MAX_VALUE)
    );

    Adminview.add(jPanel3);
    jPanel3.setBounds(0, 0, 640, 100);

    javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
    jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(
      jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(jPanel1Layout.createSequentialGroup()
        .addContainerGap()
        .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)
        .addGap(35, 35, 35))
    );
    jPanel1Layout.setVerticalGroup(
      jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(jPanel1Layout.createSequentialGroup()
        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 377, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addGap(0, 10, Short.MAX_VALUE))
    );

    Adminview.add(jPanel1);
    jPanel1.setBounds(26, 111, 260, 387);
    Adminview.add(jLabel21);
    jLabel21.setBounds(0, 0, 620, 510);

    getContentPane().add(Adminview);
    Adminview.setBounds(0, 0, 638, 517);

    reg.setBackground(new java.awt.Color(153, 153, 153));
    reg.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    reg.setLayout(null);

    TN.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    TN.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        TNActionPerformed(evt);
      }
    });
    reg.add(TN);
    TN.setBounds(300, 93, 252, 40);

    BSubmit.setBackground(new java.awt.Color(0, 204, 177));
    BSubmit.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
    BSubmit.setForeground(new java.awt.Color(255, 255, 255));
    BSubmit.setText("Submit");
    BSubmit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        BSubmitActionPerformed(evt);
      }
    });
    reg.add(BSubmit);
    BSubmit.setBounds(160, 430, 260, 60);

    EM.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    reg.add(EM);
    EM.setBounds(300, 240, 250, 40);

    jLabel1.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
    jLabel1.setForeground(new java.awt.Color(255, 255, 255));
    jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel1.setText("Registeration");
    reg.add(jLabel1);
    jLabel1.setBounds(163, 20, 320, 43);

    jLabel2.setText("Teacher name");
    reg.add(jLabel2);
    jLabel2.setBounds(10, 349, 0, 5);

    jLabel4.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
    jLabel4.setForeground(new java.awt.Color(255, 255, 255));
    jLabel4.setText("Stream");
    jLabel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    reg.add(jLabel4);
    jLabel4.setBounds(20, 170, 240, 40);

    jLabel5.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
    jLabel5.setForeground(new java.awt.Color(255, 255, 255));
    jLabel5.setText("e-maiL");
    jLabel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    reg.add(jLabel5);
    jLabel5.setBounds(20, 240, 240, 40);

    jLabel6.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
    jLabel6.setForeground(new java.awt.Color(255, 255, 255));
    jLabel6.setText("Teacher name");
    jLabel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    reg.add(jLabel6);
    jLabel6.setBounds(25, 95, 232, 40);

    jLabel7.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
    jLabel7.setForeground(new java.awt.Color(255, 255, 255));
    jLabel7.setText("Password");
    jLabel7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    reg.add(jLabel7);
    jLabel7.setBounds(20, 310, 240, 40);

    jLabel8.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
    jLabel8.setForeground(new java.awt.Color(255, 255, 255));
    jLabel8.setText("Conform Password");
    jLabel8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    reg.add(jLabel8);
    jLabel8.setBounds(20, 380, 240, 40);
    reg.add(jLabel10);
    jLabel10.setBounds(409, 332, 143, 0);

    PS.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    reg.add(PS);
    PS.setBounds(300, 310, 250, 40);

    CPS.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    CPS.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        CPSActionPerformed(evt);
      }
    });
    reg.add(CPS);
    CPS.setBounds(300, 380, 250, 40);

    jButton3.setBackground(new java.awt.Color(0, 174, 140));
    jButton3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
    jButton3.setForeground(new java.awt.Color(255, 255, 255));
    jButton3.setText("Back");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton3ActionPerformed(evt);
      }
    });
    reg.add(jButton3);
    jButton3.setBounds(505, 10, 80, 31);

    ST.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "CSE", "IT", "ECE", "EE", "ME", "CIVIL" }));
    ST.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    ST.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        STActionPerformed(evt);
      }
    });
    reg.add(ST);
    ST.setBounds(300, 170, 250, 40);

    jPanel2.setBackground(new java.awt.Color(0, 204, 177));

    javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
    jPanel2.setLayout(jPanel2Layout);
    jPanel2Layout.setHorizontalGroup(
      jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGap(0, 640, Short.MAX_VALUE)
    );
    jPanel2Layout.setVerticalGroup(
      jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGap(0, 80, Short.MAX_VALUE)
    );

    reg.add(jPanel2);
    jPanel2.setBounds(0, 0, 640, 80);
    reg.add(jLabel9);
    jLabel9.setBounds(-3, 0, 600, 530);

    getContentPane().add(reg);
    reg.setBounds(-3, -1, 620, 530);

    login.setBackground(new java.awt.Color(255, 255, 255));
    login.setBorder(new javax.swing.border.MatteBorder(null));
    login.setPreferredSize(new java.awt.Dimension(618, 517));
    login.setLayout(null);

    jLabel11.setBackground(new java.awt.Color(255, 204, 204));
    jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
    jLabel11.setForeground(new java.awt.Color(255, 255, 255));
    jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel11.setText("LOGIN");
    jLabel11.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 204), new java.awt.Color(204, 204, 204), new java.awt.Color(255, 255, 255), new java.awt.Color(255, 255, 255)));
    login.add(jLabel11);
    jLabel11.setBounds(150, 30, 280, 75);

    jLabel12.setBackground(new java.awt.Color(204, 255, 255));
    jLabel12.setFont(new java.awt.Font("Tempus Sans ITC", 3, 24)); // NOI18N
    jLabel12.setForeground(new java.awt.Color(255, 255, 255));
    jLabel12.setText("USER NAME ");
    jLabel12.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, new java.awt.Color(255, 255, 255)));
    login.add(jLabel12);
    jLabel12.setBounds(110, 150, 190, 30);

    utextf.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
    utextf.setForeground(new java.awt.Color(0, 181, 191));
    utextf.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    login.add(utextf);
    utextf.setBounds(110, 180, 440, 40);

    jLabel13.setBackground(new java.awt.Color(204, 255, 255));
    jLabel13.setFont(new java.awt.Font("Tempus Sans ITC", 3, 24)); // NOI18N
    jLabel13.setForeground(new java.awt.Color(255, 255, 255));
    jLabel13.setText(" PASSWORD ");
    jLabel13.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, new java.awt.Color(255, 255, 255)));
    login.add(jLabel13);
    jLabel13.setBounds(110, 270, 190, 30);

    ptextf.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
    ptextf.setForeground(new java.awt.Color(0, 181, 191));
    ptextf.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    ptextf.addKeyListener(new java.awt.event.KeyAdapter() {
      public void keyPressed(java.awt.event.KeyEvent evt) {
        ptextfKeyPressed(evt);
      }
    });
    login.add(ptextf);
    ptextf.setBounds(110, 300, 440, 40);

    jButton1.setBackground(new java.awt.Color(0, 181, 191));
    jButton1.setFont(new java.awt.Font("Tempus Sans ITC", 3, 36)); // NOI18N
    jButton1.setForeground(new java.awt.Color(255, 255, 255));
    jButton1.setText("Login");
    jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton1ActionPerformed(evt);
      }
    });
    login.add(jButton1);
    jButton1.setBounds(110, 380, 226, 50);

    jButton2.setBackground(new java.awt.Color(102, 255, 204));
    jButton2.setFont(new java.awt.Font("Tempus Sans ITC", 3, 36)); // NOI18N
    jButton2.setText("Register ");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton2ActionPerformed(evt);
      }
    });
    login.add(jButton2);
    jButton2.setBounds(337, 380, 210, 50);

    remeber.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        remeberActionPerformed(evt);
      }
    });
    login.add(remeber);
    remeber.setBounds(110, 350, 20, 21);

    jLabel19.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jLabel19.setForeground(new java.awt.Color(255, 255, 255));
    jLabel19.setText("Remember");
    jLabel19.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    jLabel19.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseClicked(java.awt.event.MouseEvent evt) {
        jLabel19MouseClicked(evt);
      }
    });
    login.add(jLabel19);
    jLabel19.setBounds(140, 350, 110, 20);

    back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pic/techno_wallpaper_2_0_hd_by_gredius-d5o48do.jpg"))); // NOI18N
    login.add(back);
    back.setBounds(0, -10, 620, 530);

    getContentPane().add(login);
    login.setBounds(0, 0, 618, 517);

    teacherview.setPreferredSize(new java.awt.Dimension(624, 533));
    teacherview.setLayout(null);

    jButton9.setBackground(new java.awt.Color(0, 255, 204));
    jButton9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jButton9.setForeground(new java.awt.Color(255, 255, 255));
    jButton9.setText("Start Attendence");
    jButton9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    jButton9.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton9ActionPerformed(evt);
      }
    });
    teacherview.add(jButton9);
    jButton9.setBounds(320, 110, 292, 93);

    jButton4.setBackground(new java.awt.Color(0, 204, 204));
    jButton4.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
    jButton4.setForeground(new java.awt.Color(255, 255, 255));
    jButton4.setText("Logout");
    jButton4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    jButton4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton4ActionPerformed(evt);
      }
    });
    teacherview.add(jButton4);
    jButton4.setBounds(10, 110, 114, 43);

    jButton10.setBackground(new java.awt.Color(0, 204, 204));
    jButton10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jButton10.setForeground(new java.awt.Color(255, 255, 255));
    jButton10.setText("View Students");
    jButton10.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    jButton10.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton10ActionPerformed(evt);
      }
    });
    teacherview.add(jButton10);
    jButton10.setBounds(320, 210, 292, 90);

    jButton11.setBackground(new java.awt.Color(0, 204, 204));
    jButton11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jButton11.setForeground(new java.awt.Color(255, 255, 255));
    jButton11.setText("Student Attendence");
    jButton11.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    jButton11.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton11ActionPerformed(evt);
      }
    });
    teacherview.add(jButton11);
    jButton11.setBounds(320, 310, 292, 83);

    subCode.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    subCode.setText("cs901");
    subCode.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    teacherview.add(subCode);
    subCode.setBounds(140, 110, 150, 40);

    jLabel14.setBackground(new java.awt.Color(211, 153, 171));
    jLabel14.setFont(new java.awt.Font("Algerian", 3, 24)); // NOI18N
    jLabel14.setForeground(new java.awt.Color(255, 255, 255));
    jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel14.setText(" WELCOME");
    jLabel14.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    teacherview.add(jLabel14);
    jLabel14.setBounds(120, 10, 360, 86);

    jButton12.setBackground(new java.awt.Color(0, 204, 204));
    jButton12.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jButton12.setForeground(new java.awt.Color(255, 255, 255));
    jButton12.setText("Stop Time");
    jButton12.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
    jButton12.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton12ActionPerformed(evt);
      }
    });
    teacherview.add(jButton12);
    jButton12.setBounds(320, 410, 292, 91);

    timelb.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
    timelb.setForeground(new java.awt.Color(0, 134, 205));
    timelb.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    timelb.setText("Time ");
    teacherview.add(timelb);
    timelb.setBounds(10, 158, 290, 59);

    jLabel17.setBackground(new java.awt.Color(204, 204, 204));
    jLabel17.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
    jLabel17.setForeground(new java.awt.Color(51, 51, 51));
    jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel17.setText("Start");
    teacherview.add(jLabel17);
    jLabel17.setBounds(10, 230, 50, 20);

    Start.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
    Start.setForeground(new java.awt.Color(0, 188, 242));
    Start.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    teacherview.add(Start);
    Start.setBounds(10, 250, 300, 50);

    jLabel18.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
    jLabel18.setText("End");
    teacherview.add(jLabel18);
    jLabel18.setBounds(10, 320, 50, 20);

    Stop.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
    Stop.setForeground(new java.awt.Color(0, 188, 242));
    Stop.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
    teacherview.add(Stop);
    Stop.setBounds(10, 340, 300, 50);
    teacherview.add(jLabel16);
    jLabel16.setBounds(11, 158, 300, 240);
    teacherview.add(back11);
    back11.setBounds(0, 4, 620, 530);

    getContentPane().add(teacherview);
    teacherview.setBounds(0, 0, 624, 533);

    pack();
  }// </editor-fold>//GEN-END:initComponents

    void setttime()
    {      
              Thread t= new Thread(){

        @Override
        public void run() {
            while(true){
         java.text.SimpleDateFormat T=new SimpleDateFormat("yyyy-MM-dd    HH:mm:ss:SSS");
        java.util.Date t=new java.util.Date();
               timelb.setText( T.format(t));
              
               
        }
        }
              };
              t.setDaemon(true);
              t.start();
    }
    private void BSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BSubmitActionPerformed
if(TN.getText().equals("") || ST.getSelectedItem().equals("") ||PS.getText().equals("") ||EM.getText().equals("") ){
JOptionPane.showMessageDialog(this, "fields are empty!!");

}
else{
      
       String name=TN.getText();
      String password=PS.getText();
       String cpassword=CPS.getText();
       String Email=EM.getText();
if(password.equals(cpassword)) {
        
         
              
              
          try {
              Class.forName("com.mysql.jdbc.Driver");
                      
                      Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/barcode","root","");
                      
                      
                      Statement stmt=con.createStatement();
                      stmt.execute("insert into teachers_info(T_name,e_maiL,Password,Stream,Status) values('"+name+"','"+Email+"','"+password+"','"+ST.getSelectedItem()+"','false')");
                      stmt.close();
                      
                      JOptionPane.showMessageDialog(this,"registeration sucessfull");
                      
              } catch (SQLException ex) {
                      Logger.getLogger(java1.class.getName()).log(Level.SEVERE, null, ex);
                      } catch (ClassNotFoundException ex) {
              Logger.getLogger(java1.class.getName()).log(Level.SEVERE, null, ex);
          }
}
          else{
                      javax.swing.JOptionPane.showMessageDialog(this, "password not match");
                      
                      }
 
}
    }//GEN-LAST:event_BSubmitActionPerformed

    private void CPSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CPSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CPSActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       
         if(utextf.getText()!="" || ptextf.getText()!=""){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql:///barcode","root","");
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery("select password from teachers_info where e_mail='"+utextf.getText()+"'");
            
            if(rs.next())
            {
            if(rs.getString(1).equals(ptextf.getText()))
            {
            JOptionPane.showMessageDialog(this,"login successful");
            if(utextf.getText().equals("Admin"))
            {
            Adminview.setVisible(true);
       teacherview.setVisible(false);
       reg.setVisible(false);
       login.setVisible(false);
            }
            else{
            
             Adminview.setVisible(false);
       teacherview.setVisible(true);
       reg.setVisible(false);
       login.setVisible(false);
            }
            
            }
                else
            {
            
            JOptionPane.showMessageDialog(this,"wrong password!!");
            }
            }
            else{
            JOptionPane.showMessageDialog(this,"wrong username");
            }
            
// TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(java1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(java1.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        }
        else{
        
            JOptionPane.showMessageDialog(this,"fields are empty!!");
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       Adminview.setVisible(false);
       teacherview.setVisible(false);
       reg.setVisible(true);
       login.setVisible(false);
               
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
     
 Adminview.setVisible(false);
       teacherview.setVisible(false);
       reg.setVisible(false);
       login.setVisible(true);        
// TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        StdReg stdreg=new StdReg();
        stdreg.main(null);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
     Remove.studentView();   
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
       Remove.teacherView();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
         Adminview.setVisible(false);
       teacherview.setVisible(false);
       reg.setVisible(false);
       login.setVisible(true);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void STActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_STActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_STActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
       Remove.studentAttdView();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        
         
       java1.main(null);
       Web_Barcode.webcam.close();
        Web_Barcode.webcam.close();
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void ptextfKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ptextfKeyPressed
      
        if(evt.getKeyCode()==java.awt.event.KeyEvent.VK_ENTER)
        {
        jButton1ActionPerformed(null);
        }
    }//GEN-LAST:event_ptextfKeyPressed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
     Remove.studentView();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
    
      
      if(!webcam)
      {
        Web_Barcode.webcam    = Webcam.getDefault();
                Web_Barcode.webcam.setViewSize(WebcamResolution.VGA.getSize());     
		Web_Barcode.webcam.open();
        webcam=true;
      }
      
      new Thread(){
            @Override
            public void run() {
                Web_Barcode.main(null);
                     }
        }.start();
       
    

         
              startt=new java.util.Date();
              java.text.SimpleDateFormat T=new SimpleDateFormat("yyyy-MM-dd    HH:mm:ss:SSS");
              Start.setText(T.format(startt));
             starttime=true;
         
      
     
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed

if(starttime)
{
startt=new java.util.Date();
              java.text.SimpleDateFormat T=new SimpleDateFormat("yyyy-MM-dd    HH:mm:ss:SSS");
            Stop.setText(T.format(startt));
             starttime=false;
bar.setVisible(false);

}

Web_Barcode.webcam.close(); Web_Barcode.webcam.close();

    }//GEN-LAST:event_jButton12ActionPerformed

    private void jLabel19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel19MouseClicked
       
    }//GEN-LAST:event_jLabel19MouseClicked

    private void remeberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_remeberActionPerformed
      if(remeber.isSelected())
      {
      rem=true;
      }
       else{
          rem=false;
      }
    }//GEN-LAST:event_remeberActionPerformed

    private void TNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TNActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TNActionPerformed

      

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(java1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(java1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(java1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(java1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {                         
                new java1().setVisible(true);
               
                
                java.util.Date d=new  java.util.Date();
              
            }
        });
    }

  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JPanel Adminview;
  private javax.swing.JButton BSubmit;
  private javax.swing.JTextField CPS;
  private javax.swing.JTextField EM;
  private javax.swing.JTextField PS;
  private javax.swing.JComboBox ST;
  private javax.swing.JLabel Start;
  private javax.swing.JLabel Stop;
  private javax.swing.JTextField TN;
  private javax.swing.JLabel back;
  private javax.swing.JLabel back11;
  private javax.swing.JButton jButton1;
  private javax.swing.JButton jButton10;
  private javax.swing.JButton jButton11;
  private javax.swing.JButton jButton12;
  private javax.swing.JButton jButton2;
  private javax.swing.JButton jButton3;
  private javax.swing.JButton jButton4;
  private javax.swing.JButton jButton5;
  private javax.swing.JButton jButton6;
  private javax.swing.JButton jButton7;
  private javax.swing.JButton jButton8;
  private javax.swing.JButton jButton9;
  private javax.swing.JLabel jLabel1;
  private javax.swing.JLabel jLabel10;
  private javax.swing.JLabel jLabel11;
  private javax.swing.JLabel jLabel12;
  private javax.swing.JLabel jLabel13;
  private javax.swing.JLabel jLabel14;
  private javax.swing.JLabel jLabel15;
  private javax.swing.JLabel jLabel16;
  private javax.swing.JLabel jLabel17;
  private javax.swing.JLabel jLabel18;
  private javax.swing.JLabel jLabel19;
  private javax.swing.JLabel jLabel2;
  private javax.swing.JLabel jLabel20;
  private javax.swing.JLabel jLabel21;
  private javax.swing.JLabel jLabel3;
  private javax.swing.JLabel jLabel4;
  private javax.swing.JLabel jLabel5;
  private javax.swing.JLabel jLabel6;
  private javax.swing.JLabel jLabel7;
  private javax.swing.JLabel jLabel8;
  private javax.swing.JLabel jLabel9;
  private javax.swing.JPanel jPanel1;
  private javax.swing.JPanel jPanel2;
  private javax.swing.JPanel jPanel3;
  private javax.swing.JPanel login;
  private javax.swing.JTextField ptextf;
  private javax.swing.JPanel reg;
  private javax.swing.JCheckBox remeber;
  public static javax.swing.JTextField subCode;
  private javax.swing.JPanel teacherview;
  private javax.swing.JLabel timelb;
  private javax.swing.JTextField utextf;
  // End of variables declaration//GEN-END:variables
}
